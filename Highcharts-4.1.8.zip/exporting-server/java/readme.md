#Steps to build the Highcharts Server application for Java#
See http://www.highcharts.com/docs/export-module/setting-up-the-server
